import discord
from discord.ext import commands, tasks
import requests
import asyncio
import logging
import io
from datetime import datetime
from typing import Dict, List, Any, Optional, Set
from PIL import Image, ImageEnhance, ImageFilter
from rembg import remove


# CONFIGURATION

BOT_TOKEN: str = 'MTUwOTE3MjYzNDk2Nzk5ODQ5NA.GJb6A1.8aQ_bYCT-WI4oh0DPMdYCzdn0Es589j83E2hBI'

ALLOWED_ROLE_NAMES = ["Projektleitung", "Team", "Moderator", "Admin", "Vinted Admin"]

# Hier definierst du deine Suchaufträge, Ziel-Channels und die neuen Preis-Filter (in Euro)
MONITORS: List[Dict[str, Any]] = [
    {
        "channel_id": 1508842300464304198,
        "params": {
            "search_text": "ralph lauren polo", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 15,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }

    },
    {
        "channel_id": 1508842346643722330,
        "params": {
            "search_text": "fred parry polo", 
            "order": "newest_first",
            "price_from": 0,   # Kein Mindestpreis
            "price_to": 15,     # Maximal 30€
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508842397029765230,
        "params": {
            "search_text": "lamartina polo", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 15,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508843419441565716,
        "params": {
            "search_text": "polo", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 10,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508840669865709588,
        "params": {
            "search_text": "miss me jeans", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 25,    # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508840699020443658,
        "params": {
            "search_text": "true religion jeans", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 25,    # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508841819314720919,
        "params": {
            "search_text": "gstar jeans", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 25,    # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508841753761808495,
        "params": {
            "search_text": "armani jeans", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 30,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508841865787605202,
        "params": {
            "search_text": "diesel jeans", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 30,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508841705380642979,
        "params": {
            "search_text": "dolce-gabbana jeans", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 40,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1508841865787605202,
        "params": {
            "search_text": "diesel jeans", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 30,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510562980260220948,
        "params": {
            "search_text": "nike trackpants", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 15,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510562980260220948,
        "params": {
            "search_text": "addidas trackpants", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 15,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510564387289825361,
        "params": {
            "search_text": "nike trackjacket", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 20,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510564387289825361,
        "params": {
            "search_text": "addidas trackjacket", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 20,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510564387289825361,
        "params": {
            "search_text": "fred parry jacket", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 20,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510565250095906816,
        "params": {
            "search_text": "addidas tracksuit", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 25,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510565250095906816,
        "params": {
            "search_text": "nike tracksuit", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 25,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510567237944086618,
        "params": {
            "search_text": "dolce gabbana shorts", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 15,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    },
    {
        "channel_id": 1510567237944086618,
        "params": {
            "search_text": "ralph lauren shorts", 
            "order": "newest_first",
            "price_from": 0,  # Mindestpreis in € (0 für kein Limit)
            "price_to": 15,     # Maximalpreis in € (0 für kein Limit)
            "use_size_filter": False, 
            "size_ids[]": [4, 5]      # 4 = S, 5 = M, 206 = L
        }
    }
]

# Logging-Setup
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [ %(levelname)s ] %(name)s: %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger("VintedCore")

class VintedAPIClient:
    """Professioneller HTTP-Client für die Interaktion mit der Vinted-API."""
    
    def __init__(self) -> None:
        self.session: Optional[requests.Session] = None
        self._init_session()

    def _init_session(self) -> None:
        logger.info("Initializing secure Vinted HTTP session...")
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "Connection": "keep-alive",
            "Cache-Control": "no-cache"
        })
        try:
            self.session.get("https://www.vinted.de", timeout=10)
        except requests.RequestException as e:
            logger.error(f"Session init failed: {e}")

    def fetch_products(self, search_params: Dict[str, Any]) -> List[Dict[str, Any]]:
        if not self.session:
            self._init_session()

        url = "https://www.vinted.de/api/v2/catalog/items"
        
        api_params = {}
        for k, v in search_params.items():
            if k == "use_size_filter":
                continue
            if k == "size_ids[]" and not search_params.get("use_size_filter", False):
                continue
            
            if v != 0 and v is not None and v != "" and v != []:
                api_params[k] = v

        try:
            response = self.session.get(url, params=api_params, timeout=10)
            if response.status_code in [401, 403]:
                logger.warning("Access token expired. Refreshing...")
                self._init_session()
                response = self.session.get(url, params=api_params, timeout=10)

            if response.status_code == 200:
                return response.json().get('items', [])
            return []
        except requests.RequestException:
            return []

    def fetch_single_item(self, item_id: int) -> Optional[Dict[str, Any]]:
        if not self.session:
            self._init_session()
        url = f"https://www.vinted.de/api/v2/items/{item_id}"
        
        # Cache-Buster, zwingt Vinted, frische Daten zu liefern (für Views/Likes)
        cb_params = {"timestamp": int(datetime.now().timestamp())}
        
        try:
            response = self.session.get(url, params=cb_params, timeout=10)
            if response.status_code in [401, 403]:
                self._init_session()
                response = self.session.get(url, params=cb_params, timeout=10)
                
            if response.status_code == 200:
                return response.json().get('item')
        except requests.RequestException:
            pass
        return None

class VintedButtons(discord.ui.View):
    def __init__(self, item_url: str, item_id: Any, embeds: List[discord.Embed]) -> None:
        super().__init__(timeout=None)
        self.embeds = embeds
        
        self.add_item(discord.ui.Button(label="Ansehen", url=item_url, style=discord.ButtonStyle.link, emoji="🔗"))
        
        buy_url = f"https://www.vinted.de/transaction/buy/new?item_id={item_id}"
        self.add_item(discord.ui.Button(label="Erwerben", url=buy_url, style=discord.ButtonStyle.link, emoji="💳"))

    @discord.ui.button(label="Merken", style=discord.ButtonStyle.secondary, emoji="📌", custom_id="vinted_save_btn")
    async def favorite_button(self, interaction: discord.Interaction, button: discord.ui.Button) -> None:
        try:
            await interaction.user.send(content="``[ SYSTEM ] Gespeicherter Datensatz aus dem Monitoring:``", embeds=self.embeds)
            await interaction.response.send_message("``[ OK ] Datensatz in privaten Arbeitsbereich übertragen.``", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("``[ ERR ] Zugriff verweigert. DMs deaktiviert.``", ephemeral=True)

class JanikVintedBot(commands.Bot):
    
    def __init__(self) -> None:
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True 
        super().__init__(command_prefix='!', intents=intents)
        
        self.api_client = VintedAPIClient()
        self.already_posted: Dict[int, Set[int]] = {}
        self.status_messages: Dict[int, discord.Message] = {}
        
        self.tracked_messages: Dict[int, discord.Message] = {}
        self.tracked_order: List[int] = []

        self.active_monitors: Dict[int, Dict[str, Any]] = {}
        
        for monitor in MONITORS:
            self.active_monitors[monitor["channel_id"]] = monitor["params"]

    async def setup_hook(self) -> None:
        self.live_vinted_scraper.start()
        self.live_stats_updater.start()

    async def on_ready(self) -> None:
        logger.info(f"System online. Authenticated as: {self.user.name}")

    def _parse_timestamp(self, item: Dict[str, Any]) -> str:
        ts = None
        if item.get('updated_at_ts'): ts = int(item['updated_at_ts'])
        elif item.get('created_at_ts'): ts = int(item['created_at_ts'])
        else:
            for key in ['updated_at', 'created_at']:
                if item.get(key):
                    try:
                        dt = datetime.fromisoformat(str(item[key]).replace('Z', '+00:00'))
                        ts = int(dt.timestamp())
                        break
                    except Exception:
                        pass
        
        if not ts and item.get('photos') and isinstance(item['photos'], list) and len(item['photos']) > 0:
            photo_ts = item['photos'][0].get('created_at_ts')
            if photo_ts: ts = int(photo_ts)
            
        if not ts:
            ts = int(datetime.now().timestamp())
            
        return f"<t:{ts}:R>"

    def _parse_rating(self, user_data: Dict[str, Any]) -> str:
        rating_val = user_data.get('feedback_reputation') or user_data.get('rating') or 0
        review_count = user_data.get('feedback_count') or user_data.get('reviews_count') or 0
        if rating_val and float(rating_val) > 0:
            r_num = float(rating_val)
            if r_num <= 1.0: r_num *= 5
            stars = max(0, min(5, int(round(r_num))))
            return f"{'★' * stars}{'☆' * (5 - stars)}  |  {round(r_num, 1)}/5 ({review_count})"
        return "Keine Historie vorhanden"

    def build_item_embeds(self, item: Dict[str, Any], is_update: bool = False) -> List[discord.Embed]:
        title = item.get('title', 'N/A')
        price_val = item.get('price', {}).get('amount', '0.00')
        currency = item.get('price', {}).get('currency_code', 'EUR')
        price = f"{price_val} {currency}"
        
        item_url = item.get('url', 'https://www.vinted.de')
        brand = item.get('brand_title', 'Generisch')
        size = item.get('size_title', 'N/A')
        status = item.get('status', 'N/A')
        city = item.get('city') or "Unbekannt"
        
        # Absolute Sicherheit für Likes und Views
        fav_count = int(item.get('favourite_count') or item.get('favourites_count') or item.get('favorite_count') or 0)
        view_count = int(item.get('view_count') or item.get('views_count') or 0)
        time_display = self._parse_timestamp(item)

        user_data = item.get('user', {})
        username = user_data.get('login', 'User')
        rating_display = self._parse_rating(user_data)

        user_photo_url = None
        if isinstance(user_data.get('photo'), dict): user_photo_url = user_data.get('photo', {}).get('url')

        photo_urls: List[str] = []
        photos = item.get('photos', [])
        if isinstance(photos, list):
            photo_urls = [p.get('full_size_url') or p.get('url') for p in photos if p.get('url')]

        embeds: List[discord.Embed] = []
        main_embed = discord.Embed(
            title=f"» {title}  |  {price}",
            color=0x1E1E2E, 
            url=item_url
        )
        
        main_embed.set_author(name=f"User: {username}", icon_url=user_photo_url)
        if user_photo_url: main_embed.set_thumbnail(url=user_photo_url)

        main_embed.add_field(name="❖ Brand", value=f"``{brand}``", inline=True)
        main_embed.add_field(name="◧ Size", value=f"``{size}``", inline=True)
        main_embed.add_field(name="◈ Condition", value=f"``{status}``", inline=True)
        main_embed.add_field(name="✦ Price", value=f"**{price}**", inline=True)
        main_embed.add_field(name="⛟ Location", value=f"``{city}``", inline=True)
        main_embed.add_field(name="⌚ Listed", value=time_display, inline=True)
        main_embed.add_field(name="★ Reputation", value=f"``{rating_display}``", inline=False)
        
        update_badge = f" (Zuletzt aktualisiert: {datetime.now().strftime('%H:%M:%S')})" if is_update else ""
        main_embed.add_field(name=f"⟐ Stats{update_badge}", value=f"``[ ♡ ] Favoriten: {fav_count}   |   [ ⚆ ] Aufrufe: {view_count}``", inline=False)
        
        main_embed.set_footer(text="VINTED CORE ENGINE v8.5 (STUDIO EDITION)  |  AUTH: JANIK  |  SYSTEM: ACTIVE")

        if photo_urls: main_embed.set_image(url=photo_urls[0])
        embeds.append(main_embed)

        for extra_url in photo_urls[1:4]:
            extra_embed = discord.Embed(url=item_url, color=0x1E1E2E)
            extra_embed.set_image(url=extra_url)
            embeds.append(extra_embed)

        return embeds

    async def update_dashboard(self, channel_id: int, search_params: Dict[str, Any], status: str, error_msg: str = "") -> None:
        channel = self.get_channel(channel_id)
        if not channel or not isinstance(channel, discord.TextChannel): return

        timestamp = datetime.now().strftime('%H:%M:%S')
        search_text = search_params.get('search_text', 'Unbekannt')
        
        p_from, p_to = search_params.get("price_from", 0), search_params.get("price_to", 0)
        price_info = f"[{p_from} - {p_to} EUR]" if p_from > 0 and p_to > 0 else (f"[> {p_from} EUR]" if p_from > 0 else (f"[< {p_to} EUR]" if p_to > 0 else "[ANY]"))

        # Schalter prüfen für die Anzeige im Dashboard
        use_size = search_params.get("use_size_filter", False)
        sizes = search_params.get("size_ids[]", [])
        if use_size and sizes:
            size_info = f"{', '.join(map(str, sizes))}"
        else:
            size_info = "[ALL SIZES]"

        embed = discord.Embed(title="[ SYSTEM MONITOR ]", color=0x384B59)
        if status == "aktiv":
            embed.description = f"``STATUS : ONLINE & SYNCING``\n``TIME   : {timestamp}``\n``QUERY  : {search_text}``\n``PRICE  : {price_info}``\n``SIZES  : {size_info}``"
        elif status == "fehler":
            embed.description = f"``STATUS : ERROR``\n``INFO   : {error_msg}``\n``ACTION : RECONNECTING...``"
        elif status == "offline":
            embed.color = 0x8B0000
            embed.description = f"``STATUS : OFFLINE (Gestopped)``\n``INFO   : Monitor wurde manuell beendet.``"

        embed.set_footer(text="CORE ENGINE v8.5 | BY JANIK")

        try:
            if channel_id in self.status_messages:
                await self.status_messages[channel_id].edit(embed=embed)
                return

            async for msg in channel.history(limit=10):
                if msg.author == self.user and msg.embeds and "[ SYSTEM MONITOR ]" in str(msg.embeds[0].title):
                    self.status_messages[channel_id] = msg
                    await msg.edit(embed=embed)
                    return
            self.status_messages[channel_id] = await channel.send(embed=embed)
        except discord.HTTPException as e:
            logger.error(f"Dashboard Update fehlgeschlagen: {e}")

    @tasks.loop(seconds=20)
    async def live_vinted_scraper(self) -> None:
        monitors_copy = list(self.active_monitors.items())
        
        for channel_id, params in monitors_copy:
            if channel_id not in self.already_posted: self.already_posted[channel_id] = set()
            channel = self.get_channel(channel_id)
            if not channel: continue

            try:
                items = self.api_client.fetch_products(params)
                await self.update_dashboard(channel_id, params, "aktiv")
                if not items: continue

                for item in reversed(items[:3]):
                    item_id = item.get('id')
                    if not item_id or item_id in self.already_posted[channel_id]: continue

                    self.already_posted[channel_id].add(item_id)
                    item_url = item.get('url', 'https://www.vinted.de')

                    embeds = self.build_item_embeds(item)
                    view = VintedButtons(item_url=item_url, item_id=item_id, embeds=embeds)
                    
                    try:
                        sent_msg = await channel.send(embeds=embeds, view=view)
                        self.tracked_messages[item_id] = sent_msg
                        self.tracked_order.append(item_id)
                        
                        if len(self.tracked_order) > 20:
                            oldest = self.tracked_order.pop(0)
                            self.tracked_messages.pop(oldest, None)
                    except discord.HTTPException as e:
                        logger.error(f"Senden von Produkt-Embed fehlgeschlagen: {e}")

                    await asyncio.sleep(1.5)
            except Exception as e:
                await self.update_dashboard(channel_id, params, "fehler", error_msg=str(e))
            
            await asyncio.sleep(2)

    @tasks.loop(minutes=3)
    async def live_stats_updater(self) -> None:
        if not self.tracked_order:
            return

        for item_id in list(self.tracked_order):
            msg = self.tracked_messages.get(item_id)
            if not msg: continue
            
            try:
                fresh_data = self.api_client.fetch_single_item(item_id)
                if fresh_data:
                    updated_embeds = self.build_item_embeds(fresh_data, is_update=True)
                    await msg.edit(embeds=updated_embeds)
            except discord.NotFound:
                if item_id in self.tracked_order:
                    self.tracked_order.remove(item_id)
                self.tracked_messages.pop(item_id, None)
            except Exception as e:
                logger.error(f"Failed to update stats for {item_id}: {e}")
            
            await asyncio.sleep(2)

bot = JanikVintedBot()

def is_admin_or_allowed(ctx):
    """100% sichere Rollenprüfung - Ignoriert Leerzeichen und Groß-/Kleinschreibung"""
    if not hasattr(ctx.author, "roles"):
        return False
        
    if ctx.author.guild_permissions.administrator:
        return True
        
    allowed_cleaned = [r.strip().lower() for r in ALLOWED_ROLE_NAMES]
    for role in ctx.author.roles:
        if role.name.strip().lower() in allowed_cleaned:
            return True
            
    return False

@bot.command(name="info")
async def info_command(ctx):
    embed = discord.Embed(title=" Vinted Monitor - Hilfe & Commands", color=0x384B59)
    
    embed.add_field(
        name="`!start` - Monitor erstellen", 
        value='Startet einen neuen Such-Kanal.\n**Syntax:** `!start "Suchbegriff" <MinPreis> <MaxPreis> "Größen-IDs"`\n**Beispiel:** `!start "Nike Hoodie" 10 50 "4,5"` *(4=S, 5=M, 206=L)*', 
        inline=False
    )
    
    embed.add_field(
        name="`!stop` - Monitor beenden", 
        value="Stoppt die aktuelle Vinted-Suche in dem Kanal.", 
        inline=False
    )

    embed.add_field(
        name="`!enhance` - KI Bild 📸 (Premium Look)", 
        value="Lade ein Bild hoch und schreibe `!enhance`. Der Bot entfernt den Hintergrund, fügt einen E-Commerce-Schatten hinzu, optimiert die Farben und schickt dir das Studio-Bild **in deine DMs**!", 
        inline=False
    )
    
    embed.add_field(
        name="`!clear` - DMs aufräumen", 
        value="Löscht den Zwischenspeicher in deinen privaten Direktnachrichten.", 
        inline=False
    )

    embed.set_footer(text="CORE ENGINE v8.5 | BY JANIK")
    await ctx.send(embed=embed)

@bot.command(name="enhance")
async def enhance_image(ctx):
    """KI E-Commerce Bildbearbeitung: Freistellen, HQ Upscale, Drop Shadow und Color Grading."""
    if not ctx.message.attachments:
        await ctx.send("``[ ERR ] Du musst ein Bild anhängen und '!enhance' als Kommentar dazuschreiben!``")
        return

    attachment = ctx.message.attachments[0]
    
    if not attachment.content_type or not attachment.content_type.startswith('image/'):
        await ctx.send("``[ ERR ] Die angehängte Datei ist kein gültiges Bild!``")
        return

    status_msg = await ctx.send("``[ SYSTEM ] Erstelle Bild... (Dies kann ein paar Sekunden dauern)``")

    try:
        image_bytes = await attachment.read()
        output_bytes = remove(image_bytes)
        img_no_bg = Image.open(io.BytesIO(output_bytes)).convert("RGBA")
        base_width = 1500
        wpercent = (base_width / float(img_no_bg.size[0]))
        hsize = int((float(img_no_bg.size[1]) * float(wpercent)))
        img_no_bg = img_no_bg.resize((base_width, hsize), Image.LANCZOS)
        canvas_size = (int(base_width * 1.2), int(hsize * 1.2))
        background = Image.new("RGBA", canvas_size, (244, 244, 244, 255))
        paste_x = (canvas_size[0] - img_no_bg.width) // 2
        paste_y = (canvas_size[1] - img_no_bg.height) // 2
        alpha_mask = img_no_bg.split()[3]
        shadow = Image.new("RGBA", img_no_bg.size, (0, 0, 0, 0))
        shadow.paste((0, 0, 0, 80), (0, 0), mask=alpha_mask)
        shadow = shadow.filter(ImageFilter.GaussianBlur(radius=25))
        shadow_offset_y = 30
        background.paste(shadow, (paste_x, paste_y + shadow_offset_y), shadow)
        background.paste(img_no_bg, (paste_x, paste_y), img_no_bg)
        final_image = background.convert("RGB")
        enhancer = ImageEnhance.Color(final_image)
        final_image = enhancer.enhance(1.15)  
        enhancer = ImageEnhance.Contrast(final_image)
        final_image = enhancer.enhance(1.10)  
        enhancer = ImageEnhance.Sharpness(final_image)
        final_image = enhancer.enhance(1.4)   
        output_buffer = io.BytesIO()
        final_image.save(output_buffer, format='JPEG', quality=95)
        output_buffer.seek(0)
        file = discord.File(fp=output_buffer, filename=f"premium_studio_{attachment.filename}")

        try:
            await ctx.author.send(content="``[ OK ] Dein Premium E-Commerce Bild ist fertig! 🚀``\n*Hinweis: Ein kompletter 'Ghost Mannequin'-Effekt erfordert generative KI, aber dieses Bild liefert dir den maximalen professionellen Studio-Look für Vinted.*", file=file)
            await status_msg.edit(content="``[ OK ] Bild erfolgreich generiert! Ich habe es dir in deine DMs geschickt. 📩``")
        except discord.Forbidden:
            await status_msg.edit(content="``[ ERR ] Ich kann dir keine DMs senden! Bitte aktiviere DMs für diesen Server.``")

    except Exception as e:
        logger.error(f"Fehler bei KI-Bildbearbeitung: {e}")
        await status_msg.edit(content=f"``[ ERR ] Fehler bei der KI-Verarbeitung: {str(e)}``")

@bot.command(name="start")
@commands.guild_only()
async def start_monitor(ctx, search_text: str, price_from: int = 0, price_to: int = 0, sizes: str = ""):
    if not is_admin_or_allowed(ctx):
        await ctx.send("``[ ERR ] Du hast keine Berechtigung, diesen Befehl zu verwenden!``", delete_after=10)
        return

    guild = ctx.guild
    category = ctx.channel.category 
    channel_name = f"vinted-{search_text.replace(' ', '-').lower()}"
    
    try:
        new_channel = await guild.create_text_channel(name=channel_name, category=category)
        
        params = {
            "search_text": search_text, 
            "order": "newest_first",
            "price_from": price_from,  
            "price_to": price_to,
            "use_size_filter": False
        }
        
        if sizes and sizes.lower() != "aus":
            size_list = [s.strip() for s in sizes.split(",") if s.strip().isdigit()]
            if size_list:
                params["use_size_filter"] = True
                params["size_ids[]"] = size_list
        
        bot.active_monitors[new_channel.id] = params
        
        await ctx.send(f"``[ OK ] Erfolgreich! Der Monitor sucht jetzt in {new_channel.mention} nach '{search_text}'.``")
        await bot.update_dashboard(new_channel.id, params, "aktiv")
        
    except discord.Forbidden:
        await ctx.send("``[ ERR ] Mir fehlen die Rechte, um hier Kanäle zu erstellen!``")
    except Exception as e:
        await ctx.send(f"``[ ERR ] Fehler beim Erstellen des Kanals: {e}``")

@bot.command(name="stop")
@commands.guild_only()
async def stop_monitor(ctx):
    if not is_admin_or_allowed(ctx):
        await ctx.send("``[ ERR ] Du hast keine Berechtigung, diesen Befehl zu verwenden!``", delete_after=10)
        return

    channel_id = ctx.channel.id
    if channel_id in bot.active_monitors:
        del bot.active_monitors[channel_id]
        await ctx.send("``[ OK ] Der Monitor für diesen Kanal wurde erfolgreich gestoppt!``")
        await bot.update_dashboard(channel_id, {"search_text": "Gestoppt", "price_from": 0, "price_to": 0}, "offline")
    else:
        await ctx.send("``[ WARN ] In diesem Kanal läuft momentan kein aktiver Vinted-Monitor.``")

@bot.command(name="clear")
async def clear_dms(ctx):
    if isinstance(ctx.channel, discord.DMChannel):
        status_msg = await ctx.send("``[ SYSTEM ] Starte Bereinigung der Datenbank...``")
        deleted_count = 0
        try:
            async for msg in ctx.channel.history(limit=100):
                if msg.author == bot.user and msg.id != status_msg.id:
                    await msg.delete()
                    deleted_count += 1
                    await asyncio.sleep(0.4)
            await status_msg.edit(content=f"``[ OK ] {deleted_count} Datensätze erfolgreich aus dem Cache gelöscht.``")
        except discord.HTTPException:
            await status_msg.edit(content="``[ ERR ] Fehler bei der Bereinigung der Direktnachrichten.``")
    else:
        await ctx.send("``[ WARN ] Dieser Befehl kann nur in Direktnachrichten (DMs) verwendet werden.``", delete_after=5)

# ==============================================================================
# EXECUTION ENTRYPOINT
# ==============================================================================
if __name__ == "__main__":
    try:
        bot.run(BOT_TOKEN)
    except discord.errors.LoginFailure:
        logger.critical("AUTH ERROR: Der BOT_TOKEN ist ungültig oder abgelaufen!")
    except Exception as e:
        logger.critical(f"FATAL ERROR: {e}")